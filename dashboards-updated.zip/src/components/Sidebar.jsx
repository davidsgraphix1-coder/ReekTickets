import { useState, useRef } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { FaHome, FaSignOutAlt, FaCamera, FaTimes, FaBars, FaUser, FaCog, FaTicketAlt, FaChartBar, FaChartPie, FaUsers, FaUserShield, FaCalendarAlt, FaDollarSign, FaBell, FaFileAlt, FaUndo, FaChartLine } from 'react-icons/fa';
import './Sidebar.css';

export default function Sidebar() {
  const navigate = useNavigate();
  const location = useLocation();
  const [isOpen, setIsOpen] = useState(false);
  const [profilePic, setProfilePic] = useState(localStorage.getItem('userProfilePic') || null);
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState('');
  const fileInputRef = useRef(null);
  
  const user = JSON.parse(localStorage.getItem('reek_user') || '{}');
  const userRole = user.role || 'attendee';

  const handleLogout = () => {
    localStorage.removeItem('reek_token');
    localStorage.removeItem('user');
    localStorage.removeItem('userProfilePic');
    navigate('/login');
    setIsOpen(false);
  };

  const handleProfilePicClick = () => {
    fileInputRef.current?.click();
  };

  const handleProfilePicChange = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
      setUploadError('Please select an image file');
      return;
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      setUploadError('Image must be smaller than 5MB');
      return;
    }

    setUploading(true);
    setUploadError('');

    try {
      const formData = new FormData();
      formData.append('file', file);

      const response = await fetch(`${process.env.REACT_APP_API_BASE || 'http://localhost:5000/api'}/upload`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('reek_token')}`
        },
        body: formData
      });

      if (!response.ok) {
        throw new Error('Upload failed');
      }

      const data = await response.json();
      const picUrl = data.url || data.fileUrl;

      // Update localStorage and state
      localStorage.setItem('userProfilePic', picUrl);
      setProfilePic(picUrl);

      // Update user profile in backend
      const updatedUser = { ...user, profile_picture: picUrl };
      localStorage.setItem('reek_user', JSON.stringify(updatedUser));
    } catch (err) {
      console.error('Profile picture upload error:', err);
      setUploadError('Failed to upload profile picture');
    } finally {
      setUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const getDashboardLink = () => {
    switch (userRole) {
      case 'admin':
        return '/dashboard/admin';
      case 'organizer':
        return '/dashboard/organizer';
      case 'vendor':
        return '/dashboard/vendor';
      case 'sales_agent':
        return '/dashboard/agent';
      case 'gate_entry':
        return '/dashboard/gate';
      default:
        return '/dashboard/attendee';
    }
  };

  const isActive = (path) => {
    if (path.includes('#')) {
      const [pathname, hash] = path.split('#');
      return location.pathname === pathname && window.location.hash.substring(1) === hash;
    }
    return location.pathname === path;
  };

  let menuItems = [];

  // Admin menu - full menu with all sections
  if (userRole === 'admin') {
    menuItems = [
      { path: getDashboardLink(), label: 'Dashboard', icon: FaChartPie },
      { path: '/dashboard/admin#users', label: 'Users', icon: FaUsers },
      { path: '/dashboard/admin#admins', label: 'Admins', icon: FaUserShield },
      { path: '/dashboard/admin#events', label: 'Events', icon: FaCalendarAlt },
      { path: '/dashboard/admin#payments', label: 'Payments', icon: FaDollarSign },
      { path: '/dashboard/admin#tickets', label: 'Tickets', icon: FaTicketAlt },
      { path: '/dashboard/admin#reports', label: 'Reports', icon: FaFileAlt },
      { path: '/dashboard/admin#pending-verifications', label: 'Pending Verifications', icon: FaBell },
      { path: '/dashboard/admin#payouts', label: 'Payouts', icon: FaDollarSign },
      { path: '/dashboard/admin#admin-revenue', label: 'Revenue', icon: FaChartLine },
      { path: '/dashboard/admin#organizer-withdrawals', label: 'Withdrawals', icon: FaUndo },
      { path: '/dashboard/admin#settings', label: 'Settings', icon: FaCog },
      { path: '/admin-to-admin-chat', label: 'Admin-to-Admin Chat', icon: FaHome, isChat: true },
    ];
  } else {
    // Other dashboards - simple menu
    menuItems = [
      { path: getDashboardLink(), label: 'Dashboard', icon: FaHome },
      { path: '/my-tickets', label: 'My Tickets', icon: FaTicketAlt },
      { path: '/account-settings', label: 'Settings', icon: FaCog },
      { path: '/admin-to-admin-chat', label: 'Chats', icon: FaHome, isChat: true },
    ];
  }

  // For admin users, show admin-specific menu
  if (userRole === 'admin') {
    return (
      <>
        {/* Hamburger Toggle Button */}
        <button 
          className="sidebar-toggle"
          onClick={() => setIsOpen(!isOpen)}
          aria-label="Toggle sidebar"
        >
          {isOpen ? <FaTimes /> : <FaBars />}
        </button>

        {/* Backdrop for mobile */}
        {isOpen && <div className="sidebar-backdrop" onClick={() => setIsOpen(false)} />}

        {/* Sidebar */}
        <aside className={`sidebar ${isOpen ? 'open' : ''}`}>
          <div className="sidebar-header">
            <h2>ReekTickets</h2>
            <button 
              className="close-btn"
              onClick={() => setIsOpen(false)}
            >
              <FaTimes />
            </button>
          </div>

          {/* Profile Section */}
          <div className="sidebar-profile">
            <div className="profile-pic-container">
              {profilePic ? (
                <img 
                  src={profilePic} 
                  alt="Profile"
                  className="profile-pic"
                />
              ) : (
                <div className="profile-pic-placeholder">
                  <FaUser />
                </div>
              )}
              <button 
                className="pic-upload-btn"
                onClick={handleProfilePicClick}
                disabled={uploading}
                title="Click to upload profile picture"
              >
                <FaCamera />
              </button>
              <input 
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleProfilePicChange}
                style={{ display: 'none' }}
              />
            </div>

            <div className="profile-info">
              <p className="profile-name">{user.fullName || user.full_name || 'Admin'}</p>
              <p className="profile-role">{userRole}</p>
              {uploadError && <p className="upload-error">{uploadError}</p>}
              {uploading && <p className="uploading">Uploading...</p>}
            </div>
          </div>

          {/* Admin Navigation Menu */}
          <nav className="sidebar-nav">
            {menuItems.map((item) => {
              const IconComponent = item.icon;
              return (
                <a 
                  key={item.label}
                  href={item.path.split('#')[0]}
                  className={`sidebar-link ${isActive(item.path) ? 'active' : ''}`}
                  onClick={(e) => {
                    e.preventDefault();
                    console.log('Sidebar clicked:', item.label, 'path:', item.path, 'current pathname:', location.pathname);
                    // For admin dashboard hash links, set hash directly without full navigation
                    if (item.path.includes('#')) {
                      const [path, hash] = item.path.split('#');
                      console.log('Hash navigation - path:', path, 'hash:', hash, 'current pathname:', location.pathname);
                      if (location.pathname === path) {
                        // Already on the right page, just change the hash
                        console.log('Already on page, setting hash to:', hash);
                        window.location.hash = hash;
                      } else {
                        // Not on the right page, navigate there first
                        console.log('Not on page, navigating to:', path, 'then setting hash to:', hash);
                        navigate(path);
                        setTimeout(() => {
                          window.location.hash = hash;
                        }, 100);
                      }
                    } else {
                      console.log('Regular navigation to:', item.path);
                      navigate(item.path);
                    }
                    setIsOpen(false);
                  }}
                >
                  <IconComponent className="sidebar-icon" />
                  <span>{item.label}</span>
                </a>
              );
            })}
          </nav>

          {/* Logout Button as Menu Item */}
          <button 
            className="sidebar-link logout-link"
            onClick={handleLogout}
          >
            <FaSignOutAlt className="sidebar-icon" />
            <span>Logout</span>
          </button>
        </aside>
      </>
    );
  }

  return (
    <>
      {/* Hamburger Toggle Button */}
      <button 
        className="sidebar-toggle"
        onClick={() => setIsOpen(!isOpen)}
        aria-label="Toggle sidebar"
      >
        {isOpen ? <FaTimes /> : <FaBars />}
      </button>

      {/* Backdrop for mobile */}
      {isOpen && <div className="sidebar-backdrop" onClick={() => setIsOpen(false)} />}

      {/* Sidebar */}
      <aside className={`sidebar ${isOpen ? 'open' : ''}`}>
        <div className="sidebar-header">
          <h2>ReekTickets</h2>
          <button 
            className="close-btn"
            onClick={() => setIsOpen(false)}
          >
            <FaTimes />
          </button>
        </div>

        {/* Profile Section */}
        <div className="sidebar-profile">
          <div className="profile-pic-container">
            {profilePic ? (
              <img 
                src={profilePic} 
                alt="Profile"
                className="profile-pic"
              />
            ) : (
              <div className="profile-pic-placeholder">
                <FaUser />
              </div>
            )}
            <button 
              className="pic-upload-btn"
              onClick={handleProfilePicClick}
              disabled={uploading}
              title="Click to upload profile picture"
            >
              <FaCamera />
            </button>
            <input 
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleProfilePicChange}
              style={{ display: 'none' }}
            />
          </div>

          <div className="profile-info">
            <p className="profile-name">{user.fullName || user.full_name || 'User'}</p>
            <p className="profile-role">{userRole}</p>
            {uploadError && <p className="upload-error">{uploadError}</p>}
            {uploading && <p className="uploading">Uploading...</p>}
          </div>
        </div>

        {/* Navigation Menu */}
        <nav className="sidebar-nav">
          {menuItems.map(item => {
            const Icon = item.icon;
            return (
              <a 
                key={item.path}
                href={item.path}
                className={`sidebar-link ${isActive(item.path) ? 'active' : ''}`}
                onClick={(e) => {
                  e.preventDefault();
                  navigate(item.path);
                  setIsOpen(false);
                }}
              >
                <Icon className="sidebar-icon" />
                <span>{item.label}</span>
              </a>
            );
          })}
          
          {/* Logout Button as Menu Item */}
          <button 
            className="sidebar-link logout-link"
            onClick={handleLogout}
          >
            <FaSignOutAlt className="sidebar-icon" />
            <span>Logout</span>
          </button>
        </nav>
      </aside>
    </>
  );
}
