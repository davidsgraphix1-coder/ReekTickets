import { useState, useEffect } from 'react';
import QRCode from 'react-qr-code';
import SEO from '../components/SEO';
import Sidebar from '../components/Sidebar';
import './GateEntryDashboard.css';
import { scanGateEntryTicket, issueWristband, getGateEntryLogs } from '../services/api';

export default function GateEntryDashboard() {
  const [ticketId, setTicketId] = useState('');
  const [accessCode, setAccessCode] = useState('');
  const [eventId, setEventId] = useState('');
  const [wristbandNumber, setWristbandNumber] = useState('');
  
  const [ticket, setTicket] = useState(null);
  const [scannedTicket, setScannedTicket] = useState(null);
  const [status, setStatus] = useState('');
  const [loading, setLoading] = useState(false);
  const [issuingWristband, setIssuingWristband] = useState(false);
  const [error, setError] = useState('');
  const [entryLogs, setEntryLogs] = useState([]);
  const [showLogs, setShowLogs] = useState(false);

  useEffect(() => {
    // Load entry logs if eventId is provided
    if (eventId && showLogs) {
      loadEntryLogs();
    }
  }, [eventId, showLogs]);

  const loadEntryLogs = async () => {
    try {
      const logs = await getGateEntryLogs(eventId);
      setEntryLogs(logs.data || []);
    } catch (err) {
      console.error('Error loading entry logs:', err);
    }
  };

  const handleScanTicket = async () => {
    setError('');
    setStatus('');
    setScannedTicket(null);
    
    if (!ticketId || !accessCode) {
      setError('Enter both ticket ID and access code.');
      return;
    }

    setLoading(true);
    try {
      const data = await scanGateEntryTicket(ticketId.trim(), accessCode.trim(), eventId || null);
      setScannedTicket(data.data);
      setStatus(data.message);
      setTicket(null); // Clear any previous ticket
      // Reset wristband number
      setWristbandNumber('');
    } catch (err) {
      setError(err?.message || 'Ticket scanning failed.');
    } finally {
      setLoading(false);
    }
  };

  const handleIssueWristband = async () => {
    if (!scannedTicket?.ticketId) {
      setError('No ticket scanned. Please scan a ticket first.');
      return;
    }

    setIssuingWristband(true);
    setError('');
    
    try {
      const result = await issueWristband(scannedTicket.ticketId, wristbandNumber || null);
      setStatus(result.message);
      setScannedTicket(result.data);
      setWristbandNumber('');
      
      // Reset form after successful wristband issue
      setTimeout(() => {
        setTicketId('');
        setAccessCode('');
        setScannedTicket(null);
        setStatus('');
      }, 3000);

      // Reload entry logs if visible
      if (showLogs && eventId) {
        loadEntryLogs();
      }
    } catch (err) {
      setError(err?.message || 'Could not issue wristband.');
    } finally {
      setIssuingWristband(false);
    }
  };

  const handleReset = () => {
    setTicketId('');
    setAccessCode('');
    setWristbandNumber('');
    setTicket(null);
    setScannedTicket(null);
    setStatus('');
    setError('');
  };

  const totalScanned = entryLogs.length;
  const wristbandsIssued = entryLogs.filter(l => l.wristband_issued).length;
  const pendingWristbands = totalScanned - wristbandsIssued;

  return (
    <>
      <Sidebar />
      <div className="gate-entry-dashboard page dashboard-page fade-in">
        <SEO
          title="Gate Entry Dashboard – ReekTickets"
          description="Scan and manage ticket verification and wristband issuance at event gates on ReekTickets."
        />
      
      <div className="page-head glass">
        <h1>Gate Entry & Wristband Management</h1>
        <p>Scan tickets, verify attendees, and issue wristbands for event entry.</p>
      </div>

      <section className="page-content">
        {/* Scanner Section */}
        <div className="scanner-section">
          <h2>📱 Scan Ticket</h2>
          
          <div className="form-group">
            <label>Event ID (Optional)</label>
            <input
              type="text"
              placeholder="Enter event ID to filter logs"
              value={eventId}
              onChange={(e) => setEventId(e.target.value)}
            />
          </div>

          <div className="form-row">
            <div className="form-group">
              <label>Ticket ID</label>
              <input
                type="text"
                placeholder="Enter Ticket ID"
                value={ticketId}
                onChange={(e) => setTicketId(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleScanTicket()}
              />
            </div>
            <div className="form-group">
              <label>Access Code (SMS Code)</label>
              <input
                type="text"
                placeholder="6-character code"
                value={accessCode}
                onChange={(e) => setAccessCode(e.target.value.toUpperCase())}
                maxLength="6"
                onKeyPress={(e) => e.key === 'Enter' && handleScanTicket()}
              />
            </div>
          </div>

          {error && <div className="error">{error}</div>}
          {status && <div className="success">{status}</div>}

          <button 
            className="btn btn-primary" 
            onClick={handleScanTicket} 
            disabled={loading || !ticketId || !accessCode}
          >
            {loading ? 'Scanning...' : '✓ Scan Ticket'}
          </button>

          {scannedTicket && (
            <button 
              className="btn btn-primary" 
              onClick={handleReset}
              style={{ marginTop: '10px', backgroundColor: '#6c757d' }}
            >
              Clear & Scan Next
            </button>
          )}
        </div>

        {/* Scanned Ticket Details */}
        {scannedTicket && (
          <div className="scanner-section">
            <h2>✓ Ticket Verified</h2>
            <div className="ticket-card">
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start', marginBottom: '15px' }}>
                <div>
                  <h3>{scannedTicket.eventTitle}</h3>
                  <p><strong>Attendee:</strong> {scannedTicket.attendeeName}</p>
                  <p><strong>Email:</strong> {scannedTicket.attendeeEmail}</p>
                  <p><strong>Phone:</strong> {scannedTicket.attendeePhone}</p>
                </div>
                <span className={`status-badge status-${scannedTicket.status?.toLowerCase()}`}>
                  {scannedTicket.status === 'used' ? 'Scanned' : scannedTicket.status}
                </span>
              </div>

              <hr style={{ borderColor: 'rgba(255,255,255,0.3)', margin: '15px 0' }} />

              <p><strong>Ticket Type:</strong> {scannedTicket.ticketType}</p>
              <p><strong>Entry Time:</strong> {new Date(scannedTicket.entryTime).toLocaleString()}</p>
              
              <p style={{ marginTop: '15px' }}>
                <strong>Wristband Status:</strong> {' '}
                <span className={`status-badge status-${scannedTicket.wristbandStatus}`}>
                  {scannedTicket.wristbandStatus === 'issued' ? '✓ Issued' : 'Pending'}
                </span>
              </p>

              {/* Wristband Issuance Form */}
              {scannedTicket.wristbandStatus !== 'issued' && (
                <div style={{ marginTop: '20px', paddingTop: '20px', borderTop: '1px solid rgba(255,255,255,0.3)' }}>
                  <h3>Issue Wristband</h3>
                  <div className="form-group">
                    <label>Wristband Number (Optional)</label>
                    <input
                      type="text"
                      placeholder="e.g., 001, A-001, etc."
                      value={wristbandNumber}
                      onChange={(e) => setWristbandNumber(e.target.value)}
                    />
                  </div>
                  <button 
                    className="btn btn-success" 
                    onClick={handleIssueWristband}
                    disabled={issuingWristband}
                  >
                    {issuingWristband ? 'Issuing...' : '🎫 Issue Wristband'}
                  </button>
                </div>
              )}

              {scannedTicket.wristbandStatus === 'issued' && (
                <div className="success" style={{ marginTop: '20px' }}>
                  ✓ Wristband has been issued!
                </div>
              )}
            </div>
          </div>
        )}

        {/* Entry Statistics & Logs */}
        <div style={{ marginTop: '30px' }}>
          <button 
            className="btn btn-primary"
            onClick={() => setShowLogs(!showLogs)}
            style={{ marginBottom: '20px' }}
          >
            {showLogs ? '▼ Hide Entry Logs' : '▶ Show Entry Logs & Statistics'}
          </button>

          {showLogs && eventId && (
            <div className="scanner-section">
              <h2>Entry Statistics</h2>
              <div className="entry-stats">
                <div className="stat-card">
                  <div className="stat-number">{totalScanned}</div>
                  <div className="stat-label">Total Scanned</div>
                </div>
                <div className="stat-card">
                  <div className="stat-number">{wristbandsIssued}</div>
                  <div className="stat-label">Wristbands Issued</div>
                </div>
                <div className="stat-card">
                  <div className="stat-number">{pendingWristbands}</div>
                  <div className="stat-label">Pending Wristbands</div>
                </div>
              </div>

              <h2 style={{ marginTop: '30px' }}>Recent Entries</h2>
              {entryLogs.length === 0 ? (
                <p style={{ color: '#666' }}>No entries yet for this event.</p>
              ) : (
                <div style={{ overflowX: 'auto' }}>
                  <table style={{ width: '100%', borderCollapse: 'collapse', marginTop: '15px' }}>
                    <thead>
                      <tr style={{ backgroundColor: '#f3f4f6', borderBottom: '2px solid #e5e7eb' }}>
                        <th style={{ padding: '12px', textAlign: 'left', fontWeight: '600', color: '#333' }}>Attendee</th>
                        <th style={{ padding: '12px', textAlign: 'left', fontWeight: '600', color: '#333' }}>Entry Time</th>
                        <th style={{ padding: '12px', textAlign: 'left', fontWeight: '600', color: '#333' }}>Wristband</th>
                      </tr>
                    </thead>
                    <tbody>
                      {entryLogs.map((log, idx) => (
                        <tr key={idx} style={{ borderBottom: '1px solid #e5e7eb' }}>
                          <td style={{ padding: '12px', color: '#333' }}>
                            {log.attendee?.full_name || 'Unknown'}
                          </td>
                          <td style={{ padding: '12px', color: '#666', fontSize: '14px' }}>
                            {new Date(log.entry_timestamp).toLocaleString()}
                          </td>
                          <td style={{ padding: '12px' }}>
                            {log.wristband_issued ? (
                              <span className="status-badge status-issued">✓ Issued</span>
                            ) : (
                              <span className="status-badge status-pending">Pending</span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          )}

          {showLogs && !eventId && (
            <div className="warning">
              Enter an Event ID above to view entry logs and statistics.
            </div>
          )}
        </div>
      </section>
      </div>
    </>
  );
}
